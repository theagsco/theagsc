Thanks for downloading Metrico.

This is a repeatable pattern swatch, to be opened in Illustrator.

For for best results for use in Photoshop, export the desired size from Illustrator as a *.png or other raster format and Place into Photoshop. This avoids that pesky hairline issue that sometimes plagues patterns made in Illustrator.

For more information, or if you have any questions/issues, please email hello@theagsc.com.

Thanks again,

Dave & Laura.

The AGSC.