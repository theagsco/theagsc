# Thanks for downloading _Spinkles & Winks_.

We hope you enjoy using it!

_Sprinkles & Winks_ is a repeatable pattern, to be opened in Illustrator. You are welcome to use this pattern for both personal & commercial projects. We love seeing our resources being used, so we encourage you to share you work with us—you can find us on the socials below.

If you have any questions, comments, need a hand, or want to say g'day, you can reach us at feedback@theagsc.com. We look forward to hearing from you.

Laura & Dave.

[The AGSC](http://theagsc.com) | [Twitter](http://twitter.com/theagsc) | [Instagram](http://instagram.com/theagsc) | [Facebook](http://fb.com/theagsc) | [Pinterest](http://pinterest.com/theagsc)